# EgoHand3D processing report

Generated from actual processing records. Detection coverage is not recall without ground truth.
MANO consistency checks serialization/reconstruction, not pose estimation accuracy.
run_config.json records asset/input identities, code hashes and options. index.csv maps artifacts to inputs.
Images and meshes are stored in overlays/ and meshes/.

|Item|Value|
|---|---|
|Run state|completed|
|Processed frames|3|
|Frames containing predictions|3|
|Hands|8|
|MANO consistency failures|8|
|Failed tasks|0|
|Mean frame processing seconds|1.019546200831731|
